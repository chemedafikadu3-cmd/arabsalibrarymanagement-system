import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes, Navigate } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import { Layout } from "@/components/Layout";
import { PublicLayout } from "@/components/PublicLayout";
import Dashboard from "@/pages/Dashboard";
import Books from "@/pages/Books";
import Students from "@/pages/Students";
import IssueReturn from "@/pages/IssueReturn";
import Fines from "@/pages/Fines";
import Reports from "@/pages/Reports";
import UserManagement from "@/pages/UserManagement";
import Login from "@/pages/Login";
import Home from "@/pages/Home";
import About from "@/pages/About";
import Blogs from "@/pages/Blogs";
import Contact from "@/pages/Contact";
import NotFound from "@/pages/NotFound";

const queryClient = new QueryClient();

function ProtectedRoutes() {
  const { isAuthenticated } = useAuth();
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  return <Layout />;
}

function AdminRoute({ children }: { children: React.ReactNode }) {
  const { hasPermission } = useAuth();
  if (!hasPermission("manage-users")) return <Navigate to="/dashboard" replace />;
  return <>{children}</>;
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            {/* Public pages */}
            <Route element={<PublicLayout />}>
              <Route path="/" element={<Home />} />
              <Route path="/about" element={<About />} />
              <Route path="/blogs" element={<Blogs />} />
              <Route path="/contact" element={<Contact />} />
            </Route>

            <Route path="/login" element={<Login />} />

            {/* Protected admin/library pages */}
            <Route element={<ProtectedRoutes />}>
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/books" element={<Books />} />
              <Route path="/students" element={<Students />} />
              <Route path="/transactions" element={<IssueReturn />} />
              <Route path="/fines" element={<Fines />} />
              <Route path="/reports" element={<Reports />} />
              <Route path="/users" element={<AdminRoute><UserManagement /></AdminRoute>} />
            </Route>

            <Route path="*" element={<NotFound />} />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
