import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/AppSidebar";
import { Outlet, useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export function Layout() {
  const { logout, currentUser } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  const roleColor: Record<string, string> = {
    admin: "bg-primary/15 text-primary",
    "sub-admin": "bg-accent/15 text-accent",
    librarian: "bg-amber-500/15 text-amber-700",
  };

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <AppSidebar />
        <div className="flex-1 flex flex-col min-w-0">
          <header className="h-14 flex items-center border-b bg-card px-4 gap-4 shrink-0">
            <SidebarTrigger />
            <div className="ml-auto flex items-center gap-3">
              <Badge variant="outline" className={`text-xs font-semibold ${roleColor[currentUser?.role || "librarian"]}`}>
                {currentUser?.role || "user"}
              </Badge>
              <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground text-xs font-semibold">
                {currentUser?.fullName?.split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase() || "AD"}
              </div>
              <span className="text-sm font-medium hidden sm:inline">{currentUser?.fullName || "Admin"}</span>
              <Button variant="ghost" size="icon" onClick={handleLogout} title="Logout" className="text-destructive hover:bg-destructive/10">
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </header>
          <main className="flex-1 overflow-auto p-4 md:p-6">
            <Outlet />
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
