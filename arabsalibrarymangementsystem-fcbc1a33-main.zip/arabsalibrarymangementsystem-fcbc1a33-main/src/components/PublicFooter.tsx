import { GraduationCap } from "lucide-react";
import { Link } from "react-router-dom";

export function PublicFooter() {
  return (
    <footer className="border-t bg-card">
      <div className="max-w-7xl mx-auto px-4 md:px-8 py-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="w-8 h-8 rounded-lg gradient-primary flex items-center justify-center">
                <GraduationCap className="w-4 h-4 text-primary-foreground" />
              </div>
              <span className="font-extrabold text-foreground" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                Arabsa School
              </span>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Empowering education through modern library management and digital resources.
            </p>
          </div>
          <div>
            <h4 className="font-semibold text-sm mb-3 text-foreground">Quick Links</h4>
            <div className="space-y-2">
              {[
                { label: "Home", path: "/" },
                { label: "About Us", path: "/about" },
                { label: "Blogs", path: "/blogs" },
                { label: "Contact", path: "/contact" },
              ].map((l) => (
                <Link key={l.path} to={l.path} className="block text-sm text-muted-foreground hover:text-primary transition-colors">
                  {l.label}
                </Link>
              ))}
            </div>
          </div>
          <div>
            <h4 className="font-semibold text-sm mb-3 text-foreground">Contact Info</h4>
            <div className="space-y-2 text-sm text-muted-foreground">
              <p>📧 info@arabsaschool.edu</p>
              <p>📞 +251 911 000 000</p>
              <p>📍 Addis Ababa, Ethiopia</p>
            </div>
          </div>
        </div>
        <div className="mt-8 pt-6 border-t text-center text-xs text-muted-foreground">
          © {new Date().getFullYear()} Arabsa School Library. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
