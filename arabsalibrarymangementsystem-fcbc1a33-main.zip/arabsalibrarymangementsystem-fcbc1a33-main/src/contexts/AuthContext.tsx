import { createContext, useContext, useState, ReactNode } from "react";

export type UserRole = "admin" | "sub-admin" | "librarian";

export interface AppUser {
  id: string;
  username: string;
  password: string;
  fullName: string;
  role: UserRole;
  active: boolean;
  createdAt: string;
}

interface AuthContextType {
  isAuthenticated: boolean;
  currentUser: AppUser | null;
  login: (username: string, password: string) => boolean;
  logout: () => void;
  changePassword: (oldPassword: string, newPassword: string) => boolean;
  getUsers: () => AppUser[];
  addUser: (user: Omit<AppUser, "id" | "createdAt">) => boolean;
  updateUser: (id: string, updates: Partial<Omit<AppUser, "id" | "createdAt">>) => boolean;
  deleteUser: (id: string) => boolean;
  hasPermission: (permission: string) => boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

const USERS_KEY = "lms_users";
const SESSION_KEY = "lms_auth_user";

const defaultUsers: AppUser[] = [
  {
    id: "U001",
    username: "admin",
    password: "Arabsa@2024",
    fullName: "System Administrator",
    role: "admin",
    active: true,
    createdAt: "2024-01-01",
  },
];

function loadUsers(): AppUser[] {
  try {
    const raw = localStorage.getItem(USERS_KEY);
    return raw ? JSON.parse(raw) : defaultUsers;
  } catch {
    return defaultUsers;
  }
}

function saveUsers(users: AppUser[]) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

const ROLE_PERMISSIONS: Record<UserRole, string[]> = {
  admin: ["dashboard", "books", "students", "transactions", "fines", "reports", "user-management", "manage-users", "change-password"],
  "sub-admin": ["dashboard", "books", "students", "transactions", "fines", "reports", "change-password"],
  librarian: ["dashboard", "books", "transactions", "fines", "change-password"],
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [users, setUsers] = useState<AppUser[]>(loadUsers);
  const [currentUser, setCurrentUser] = useState<AppUser | null>(() => {
    try {
      const raw = sessionStorage.getItem(SESSION_KEY);
      if (!raw) return null;
      const saved = JSON.parse(raw);
      const allUsers = loadUsers();
      return allUsers.find((u) => u.id === saved.id && u.active) || null;
    } catch {
      return null;
    }
  });

  const isAuthenticated = !!currentUser;

  const login = (username: string, password: string): boolean => {
    const user = users.find((u) => u.username === username && u.password === password && u.active);
    if (user) {
      setCurrentUser(user);
      sessionStorage.setItem(SESSION_KEY, JSON.stringify({ id: user.id }));
      return true;
    }
    return false;
  };

  const logout = () => {
    setCurrentUser(null);
    sessionStorage.removeItem(SESSION_KEY);
  };

  const changePassword = (oldPassword: string, newPassword: string): boolean => {
    if (!currentUser || currentUser.password !== oldPassword) return false;
    const updated = users.map((u) =>
      u.id === currentUser.id ? { ...u, password: newPassword } : u
    );
    setUsers(updated);
    saveUsers(updated);
    const updatedUser = { ...currentUser, password: newPassword };
    setCurrentUser(updatedUser);
    return true;
  };

  const getUsers = () => users;

  const addUser = (user: Omit<AppUser, "id" | "createdAt">): boolean => {
    if (users.some((u) => u.username === user.username)) return false;
    const maxNum = users.reduce((m, u) => {
      const n = parseInt(u.id.replace("U", ""));
      return n > m ? n : m;
    }, 0);
    const newUser: AppUser = {
      ...user,
      id: `U${String(maxNum + 1).padStart(3, "0")}`,
      createdAt: new Date().toISOString().split("T")[0],
    };
    const updated = [...users, newUser];
    setUsers(updated);
    saveUsers(updated);
    return true;
  };

  const updateUser = (id: string, updates: Partial<Omit<AppUser, "id" | "createdAt">>): boolean => {
    if (updates.username && users.some((u) => u.username === updates.username && u.id !== id)) return false;
    const updated = users.map((u) => (u.id === id ? { ...u, ...updates } : u));
    setUsers(updated);
    saveUsers(updated);
    if (currentUser?.id === id) {
      setCurrentUser({ ...currentUser, ...updates } as AppUser);
    }
    return true;
  };

  const deleteUser = (id: string): boolean => {
    if (id === currentUser?.id) return false; // can't delete self
    const updated = users.filter((u) => u.id !== id);
    setUsers(updated);
    saveUsers(updated);
    return true;
  };

  const hasPermission = (permission: string): boolean => {
    if (!currentUser) return false;
    return ROLE_PERMISSIONS[currentUser.role]?.includes(permission) ?? false;
  };

  return (
    <AuthContext.Provider
      value={{
        isAuthenticated,
        currentUser,
        login,
        logout,
        changePassword,
        getUsers,
        addUser,
        updateUser,
        deleteUser,
        hasPermission,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
