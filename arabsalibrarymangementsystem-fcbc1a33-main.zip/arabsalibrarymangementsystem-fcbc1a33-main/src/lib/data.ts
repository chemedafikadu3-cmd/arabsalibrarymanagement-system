// Types
export interface Book {
  id: string;
  title: string;
  author: string;
  isbn: string;
  category: "Pre-Primary" | "Primary" | "Middle School";
  quantity: number;
  available: number;
}

export interface Student {
  id: string;
  name: string;
  class: string;
  section: string;
  phone: string;
  admissionDate: string;
}

export interface Transaction {
  id: string;
  studentId: string;
  bookId: string;
  issueDate: string;
  dueDate: string;
  returnDate: string | null;
  fineAmount: number;
  finePaid: boolean;
}

// Sample data
const sampleBooks: Book[] = [
  { id: "B001", title: "The Very Hungry Caterpillar", author: "Eric Carle", isbn: "978-0399226908", category: "Pre-Primary", quantity: 5, available: 3 },
  { id: "B002", title: "Goodnight Moon", author: "Margaret Wise Brown", isbn: "978-0064430173", category: "Pre-Primary", quantity: 4, available: 4 },
  { id: "B003", title: "Charlotte's Web", author: "E.B. White", isbn: "978-0061124952", category: "Primary", quantity: 6, available: 4 },
  { id: "B004", title: "Matilda", author: "Roald Dahl", isbn: "978-0142410370", category: "Primary", quantity: 5, available: 2 },
  { id: "B005", title: "Harry Potter and the Sorcerer's Stone", author: "J.K. Rowling", isbn: "978-0590353427", category: "Middle School", quantity: 8, available: 5 },
  { id: "B006", title: "The Giver", author: "Lois Lowry", isbn: "978-0544336261", category: "Middle School", quantity: 4, available: 3 },
  { id: "B007", title: "Where the Wild Things Are", author: "Maurice Sendak", isbn: "978-0060254926", category: "Pre-Primary", quantity: 3, available: 2 },
  { id: "B008", title: "Wonder", author: "R.J. Palacio", isbn: "978-0375869020", category: "Middle School", quantity: 6, available: 6 },
  { id: "B009", title: "Diary of a Wimpy Kid", author: "Jeff Kinney", isbn: "978-0810993136", category: "Primary", quantity: 7, available: 5 },
  { id: "B010", title: "The BFG", author: "Roald Dahl", isbn: "978-0142410387", category: "Primary", quantity: 4, available: 3 },
];

const sampleStudents: Student[] = [
  { id: "S001", name: "Ahmed Ali", class: "KG-1", section: "A", phone: "0911234567", admissionDate: "2024-09-01" },
  { id: "S002", name: "Sara Mohammed", class: "KG-2", section: "B", phone: "0912345678", admissionDate: "2024-09-01" },
  { id: "S003", name: "Yonas Tekle", class: "Grade 1", section: "A", phone: "0913456789", admissionDate: "2023-09-01" },
  { id: "S004", name: "Hana Girma", class: "Grade 3", section: "B", phone: "0914567890", admissionDate: "2023-09-01" },
  { id: "S005", name: "Dawit Haile", class: "Grade 5", section: "A", phone: "0915678901", admissionDate: "2022-09-01" },
  { id: "S006", name: "Meron Abebe", class: "Grade 7", section: "A", phone: "0916789012", admissionDate: "2022-09-01" },
  { id: "S007", name: "Kidist Lemma", class: "Grade 8", section: "B", phone: "0917890123", admissionDate: "2021-09-01" },
  { id: "S008", name: "Solomon Bekele", class: "Grade 6", section: "A", phone: "0918901234", admissionDate: "2022-09-01" },
];

const sampleTransactions: Transaction[] = [
  { id: "T001", studentId: "S003", bookId: "B003", issueDate: "2026-02-15", dueDate: "2026-03-01", returnDate: null, fineAmount: 0, finePaid: false },
  { id: "T002", studentId: "S005", bookId: "B005", issueDate: "2026-02-20", dueDate: "2026-03-06", returnDate: null, fineAmount: 0, finePaid: false },
  { id: "T003", studentId: "S006", bookId: "B006", issueDate: "2026-03-01", dueDate: "2026-03-15", returnDate: null, fineAmount: 0, finePaid: false },
  { id: "T004", studentId: "S004", bookId: "B004", issueDate: "2026-02-01", dueDate: "2026-02-15", returnDate: "2026-02-20", fineAmount: 5, finePaid: true },
  { id: "T005", studentId: "S001", bookId: "B001", issueDate: "2026-03-10", dueDate: "2026-03-24", returnDate: null, fineAmount: 0, finePaid: false },
];

// localStorage helpers
const KEYS = { books: "lms_books", students: "lms_students", transactions: "lms_transactions" };

function load<T>(key: string, fallback: T[]): T[] {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch { return fallback; }
}

function save<T>(key: string, data: T[]) {
  localStorage.setItem(key, JSON.stringify(data));
}

export function getBooks(): Book[] { return load(KEYS.books, sampleBooks); }
export function saveBooks(b: Book[]) { save(KEYS.books, b); }

export function getStudents(): Student[] { return load(KEYS.students, sampleStudents); }
export function saveStudents(s: Student[]) { save(KEYS.students, s); }

export function getTransactions(): Transaction[] { return load(KEYS.transactions, sampleTransactions); }
export function saveTransactions(t: Transaction[]) { save(KEYS.transactions, t); }

export const FINE_PER_DAY = 1; // birr per day

export function calculateFine(dueDate: string, returnDate?: string): number {
  const due = new Date(dueDate);
  const ret = returnDate ? new Date(returnDate) : new Date();
  const diff = Math.floor((ret.getTime() - due.getTime()) / (1000 * 60 * 60 * 24));
  return diff > 0 ? diff * FINE_PER_DAY : 0;
}

export function generateId(prefix: string, items: { id: string }[]): string {
  const max = items.reduce((m, i) => {
    const n = parseInt(i.id.replace(prefix, ""));
    return n > m ? n : m;
  }, 0);
  return `${prefix}${String(max + 1).padStart(3, "0")}`;
}
