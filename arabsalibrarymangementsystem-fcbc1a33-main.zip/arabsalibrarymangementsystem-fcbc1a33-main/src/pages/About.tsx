import { Card, CardContent } from "@/components/ui/card";
import { GraduationCap, BookOpen, Heart, Target, Eye, Award } from "lucide-react";

export default function About() {
  return (
    <div>
      {/* Header */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 gradient-primary opacity-90" />
        <div className="relative max-w-7xl mx-auto px-4 md:px-8 py-16 md:py-24">
          <h1 className="text-3xl md:text-5xl font-extrabold text-white mb-4">About Us</h1>
          <p className="text-lg text-white/75 max-w-lg">
            Learn about Arabsa School's mission, vision, and commitment to quality education.
          </p>
        </div>
      </section>

      {/* Story */}
      <section className="max-w-7xl mx-auto px-4 md:px-8 py-16">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-2xl md:text-3xl font-extrabold text-foreground mb-4">Our Story</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              Founded over 25 years ago, Arabsa School has been a beacon of educational excellence in Addis Ababa. Our library sits at the heart of the school, serving as the intellectual hub for students, teachers, and the community.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              With a growing collection of over 12,000 books and modern digital resources, we continue to evolve and adapt to meet the needs of 21st-century learners.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {[
              { icon: GraduationCap, label: "25+ Years", sub: "Of Excellence" },
              { icon: BookOpen, label: "12,000+", sub: "Books" },
              { icon: Heart, label: "2,500+", sub: "Students" },
              { icon: Award, label: "50+", sub: "Awards" },
            ].map((item) => (
              <Card key={item.label} className="text-center">
                <CardContent className="p-6">
                  <item.icon className="w-8 h-8 text-primary mx-auto mb-2" />
                  <p className="font-extrabold text-xl text-foreground">{item.label}</p>
                  <p className="text-xs text-muted-foreground">{item.sub}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="bg-muted">
        <div className="max-w-7xl mx-auto px-4 md:px-8 py-16">
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="border-0 shadow-lg">
              <CardContent className="p-8">
                <div className="w-12 h-12 rounded-xl gradient-primary flex items-center justify-center mb-4">
                  <Target className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-extrabold text-foreground mb-3">Our Mission</h3>
                <p className="text-muted-foreground leading-relaxed">
                  To provide an inclusive, resource-rich learning environment that empowers every student to reach their full academic potential through access to knowledge and modern educational tools.
                </p>
              </CardContent>
            </Card>
            <Card className="border-0 shadow-lg">
              <CardContent className="p-8">
                <div className="w-12 h-12 rounded-xl gradient-accent flex items-center justify-center mb-4">
                  <Eye className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-extrabold text-foreground mb-3">Our Vision</h3>
                <p className="text-muted-foreground leading-relaxed">
                  To be a leading educational institution recognized for nurturing curious minds, fostering critical thinking, and building a community of lifelong learners.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
