import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, User, ArrowRight } from "lucide-react";

const blogPosts = [
  {
    id: 1,
    title: "New Books Added to Our Science Collection",
    excerpt: "We've added over 200 new science and technology books to our library, covering topics from astrophysics to zoology.",
    author: "Library Staff",
    date: "Mar 10, 2026",
    category: "Announcements",
  },
  {
    id: 2,
    title: "Reading Week 2026: Schedule & Activities",
    excerpt: "Join us for our annual Reading Week celebration with author visits, reading challenges, and book fairs.",
    author: "Admin",
    date: "Mar 5, 2026",
    category: "Events",
  },
  {
    id: 3,
    title: "Tips for Effective Research Using Library Resources",
    excerpt: "Learn how to make the most of our digital catalog, reference section, and online databases for your research projects.",
    author: "Ms. Sara",
    date: "Feb 28, 2026",
    category: "Tips",
  },
  {
    id: 4,
    title: "Student Book Review: 'Things Fall Apart'",
    excerpt: "Grade 11 student Kedir shares his thoughtful review of Chinua Achebe's classic novel and why it still resonates today.",
    author: "Kedir Ahmed",
    date: "Feb 20, 2026",
    category: "Reviews",
  },
  {
    id: 5,
    title: "Library Hours Extended During Exam Season",
    excerpt: "Great news! The library will now stay open until 8 PM on weekdays during the upcoming exam period.",
    author: "Admin",
    date: "Feb 15, 2026",
    category: "Announcements",
  },
  {
    id: 6,
    title: "Digital Literacy Workshop for Students",
    excerpt: "A free workshop on using digital tools for academic research, citation management, and online safety.",
    author: "IT Department",
    date: "Feb 10, 2026",
    category: "Events",
  },
];

const categoryColors: Record<string, string> = {
  Announcements: "bg-primary/10 text-primary",
  Events: "bg-accent/10 text-accent",
  Tips: "bg-amber-500/10 text-amber-700",
  Reviews: "bg-purple/10 text-purple",
};

export default function Blogs() {
  return (
    <div>
      {/* Header */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 gradient-purple opacity-90" />
        <div className="relative max-w-7xl mx-auto px-4 md:px-8 py-16 md:py-24">
          <h1 className="text-3xl md:text-5xl font-extrabold text-white mb-4">Blog & News</h1>
          <p className="text-lg text-white/75 max-w-lg">
            Stay updated with the latest announcements, events, and stories from our library.
          </p>
        </div>
      </section>

      {/* Blog Grid */}
      <section className="max-w-7xl mx-auto px-4 md:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {blogPosts.map((post) => (
            <Card key={post.id} className="group hover:shadow-lg transition-all cursor-pointer border">
              <CardContent className="p-6 flex flex-col h-full">
                <Badge variant="secondary" className={`w-fit text-xs mb-3 ${categoryColors[post.category] || ""}`}>
                  {post.category}
                </Badge>
                <h3 className="font-bold text-lg text-foreground mb-2 group-hover:text-primary transition-colors">
                  {post.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed mb-4 flex-1">
                  {post.excerpt}
                </p>
                <div className="flex items-center justify-between text-xs text-muted-foreground pt-3 border-t">
                  <div className="flex items-center gap-1">
                    <User className="w-3 h-3" /> {post.author}
                  </div>
                  <div className="flex items-center gap-1">
                    <Calendar className="w-3 h-3" /> {post.date}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    </div>
  );
}
