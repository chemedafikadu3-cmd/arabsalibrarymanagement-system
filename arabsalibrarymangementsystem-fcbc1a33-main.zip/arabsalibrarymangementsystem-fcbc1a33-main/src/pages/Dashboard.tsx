import { BookOpen, Users, ArrowLeftRight, AlertTriangle, DollarSign } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from "@/components/ui/chart";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, PieChart, Pie, Cell, Area, AreaChart } from "recharts";
import { getBooks, getStudents, getTransactions, calculateFine } from "@/lib/data";

const Dashboard = () => {
  const books = getBooks();
  const students = getStudents();
  const transactions = getTransactions();

  const totalBooks = books.reduce((s, b) => s + b.quantity, 0);
  const availableBooks = books.reduce((s, b) => s + b.available, 0);
  const issuedBooks = totalBooks - availableBooks;
  const activeTransactions = transactions.filter((t) => !t.returnDate);
  const overdueTransactions = activeTransactions.filter((t) => new Date(t.dueDate) < new Date());
  const pendingFines = transactions
    .filter((t) => !t.finePaid)
    .reduce((s, t) => s + (t.returnDate ? t.fineAmount : calculateFine(t.dueDate)), 0);

  const statCards = [
    { label: "Total Books", value: totalBooks, icon: BookOpen, gradient: "gradient-primary" },
    { label: "Issued Books", value: issuedBooks, icon: ArrowLeftRight, gradient: "gradient-warning" },
    { label: "Total Students", value: students.length, icon: Users, gradient: "gradient-accent" },
    { label: "Overdue", value: overdueTransactions.length, icon: AlertTriangle, gradient: "gradient-destructive" },
    { label: "Pending Fines", value: `${pendingFines} Birr`, icon: DollarSign, gradient: "gradient-purple" },
  ];

  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const monthlyData = monthNames.map((month, i) => {
    const count = transactions.filter((t) => {
      const d = new Date(t.issueDate);
      return d.getMonth() === i && d.getFullYear() === 2026;
    }).length;
    return { month, issued: count };
  });

  const monthlyChartConfig: ChartConfig = {
    issued: { label: "Books Issued", color: "hsl(var(--primary))" },
  };

  const categoryData = [
    { name: "Pre-Primary", value: books.filter((b) => b.category === "Pre-Primary").reduce((s, b) => s + b.quantity, 0), fill: "hsl(var(--primary))" },
    { name: "Primary", value: books.filter((b) => b.category === "Primary").reduce((s, b) => s + b.quantity, 0), fill: "hsl(var(--accent))" },
    { name: "Middle School", value: books.filter((b) => b.category === "Middle School").reduce((s, b) => s + b.quantity, 0), fill: "hsl(var(--warning))" },
  ];

  const categoryChartConfig: ChartConfig = {
    "Pre-Primary": { label: "Pre-Primary", color: "hsl(var(--primary))" },
    Primary: { label: "Primary", color: "hsl(var(--accent))" },
    "Middle School": { label: "Middle School", color: "hsl(var(--warning))" },
  };

  const availabilityData = [
    { name: "Available", value: availableBooks, fill: "hsl(var(--accent))" },
    { name: "Issued", value: issuedBooks, fill: "hsl(var(--destructive))" },
  ];

  const availabilityConfig: ChartConfig = {
    Available: { label: "Available", color: "hsl(var(--accent))" },
    Issued: { label: "Issued", color: "hsl(var(--destructive))" },
  };

  const recentActivity = activeTransactions.slice(0, 5).map((t) => {
    const student = students.find((s) => s.id === t.studentId);
    const book = books.find((b) => b.id === t.bookId);
    const overdue = new Date(t.dueDate) < new Date();
    return { ...t, studentName: student?.name ?? "Unknown", bookTitle: book?.title ?? "Unknown", overdue };
  });

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Colorful Page Header */}
      <div className="gradient-page-header rounded-xl p-6 text-white shadow-lg">
        <h1 className="text-3xl font-extrabold text-white">Dashboard</h1>
        <p className="text-white/80 text-sm font-medium mt-1">Arabsa Pre-Primary, Primary & Middle School Library</p>
      </div>

      {/* Colorful Stat Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {statCards.map((s, i) => (
          <Card
            key={s.label}
            className="hover:shadow-xl hover:scale-[1.03] transition-all duration-300 cursor-default overflow-hidden border-0 shadow-md animate-scale-in"
            style={{ animationDelay: `${i * 80}ms`, animationFillMode: "backwards" }}
          >
            <CardContent className="p-0">
              <div className={`${s.gradient} p-3 flex justify-center`}>
                <s.icon className="h-6 w-6 text-white" />
              </div>
              <div className="p-4 text-center">
                <p className="text-2xl font-extrabold tracking-tight">{s.value}</p>
                <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mt-1">{s.label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2 border-0 shadow-md animate-fade-in" style={{ animationDelay: "200ms", animationFillMode: "backwards" }}>
          <CardHeader>
            <CardTitle className="text-lg font-extrabold flex items-center gap-2">
              <span className="w-3 h-3 rounded-full gradient-primary inline-block" />
              Books Issued Per Month
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer config={monthlyChartConfig} className="h-[260px] w-full">
              <AreaChart data={monthlyData} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="gradientIssued" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 12 }} />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Area type="monotone" dataKey="issued" stroke="hsl(var(--primary))" strokeWidth={3} fill="url(#gradientIssued)" animationDuration={1200} />
              </AreaChart>
            </ChartContainer>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-md animate-fade-in" style={{ animationDelay: "350ms", animationFillMode: "backwards" }}>
          <CardHeader>
            <CardTitle className="text-lg font-extrabold flex items-center gap-2">
              <span className="w-3 h-3 rounded-full gradient-accent inline-block" />
              Category Distribution
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer config={categoryChartConfig} className="h-[220px] w-full">
              <PieChart>
                <ChartTooltip content={<ChartTooltipContent />} />
                <Pie data={categoryData} cx="50%" cy="50%" innerRadius={50} outerRadius={85} paddingAngle={4} dataKey="value" nameKey="name" animationDuration={1000} strokeWidth={2} stroke="hsl(var(--card))">
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
              </PieChart>
            </ChartContainer>
            <div className="flex justify-center gap-4 mt-2">
              {categoryData.map((c) => (
                <div key={c.name} className="flex items-center gap-1.5 text-xs font-bold">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: c.fill }} />
                  {c.name} ({c.value})
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="border-0 shadow-md animate-fade-in" style={{ animationDelay: "450ms", animationFillMode: "backwards" }}>
          <CardHeader>
            <CardTitle className="text-lg font-extrabold flex items-center gap-2">
              <span className="w-3 h-3 rounded-full gradient-warning inline-block" />
              Book Availability
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer config={availabilityConfig} className="h-[200px] w-full">
              <BarChart data={availabilityData} layout="vertical" margin={{ top: 5, right: 20, left: 10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 12 }} />
                <YAxis type="category" dataKey="name" tick={{ fontSize: 13, fontWeight: 700 }} width={80} />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Bar dataKey="value" radius={[0, 8, 8, 0]} animationDuration={1000}>
                  {availabilityData.map((entry, index) => (
                    <Cell key={`bar-${index}`} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ChartContainer>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-md animate-fade-in" style={{ animationDelay: "550ms", animationFillMode: "backwards" }}>
          <CardHeader>
            <CardTitle className="text-lg font-extrabold flex items-center gap-2">
              <span className="w-3 h-3 rounded-full gradient-destructive inline-block" />
              Currently Issued Books
            </CardTitle>
          </CardHeader>
          <CardContent>
            {recentActivity.length === 0 ? (
              <p className="text-muted-foreground text-sm">No books currently issued.</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Student</TableHead>
                    <TableHead>Book</TableHead>
                    <TableHead>Due Date</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentActivity.map((a) => (
                    <TableRow key={a.id}>
                      <TableCell className="font-semibold">{a.studentName}</TableCell>
                      <TableCell>{a.bookTitle}</TableCell>
                      <TableCell>{a.dueDate}</TableCell>
                      <TableCell>
                        {a.overdue ? (
                          <Badge className="gradient-destructive text-white border-0">Overdue</Badge>
                        ) : (
                          <Badge className="gradient-accent text-white border-0">Active</Badge>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
