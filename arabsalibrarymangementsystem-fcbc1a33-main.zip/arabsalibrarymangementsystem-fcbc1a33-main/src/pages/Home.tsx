import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { BookOpen, Users, ArrowRight, Sparkles, Globe, Clock, Library } from "lucide-react";
import { getBooks, getStudents } from "@/lib/data";
import schoolLogo from "@/assets/school-logo.jpg";

const features = [
  {
    icon: BookOpen,
    title: "Rich Collection",
    description: "Access thousands of books across all subjects and genres, from textbooks to world literature.",
  },
  {
    icon: Globe,
    title: "Digital Access",
    description: "Browse our catalog online, check availability, and manage your borrowing from anywhere.",
  },
  {
    icon: Sparkles,
    title: "Modern Facilities",
    description: "Enjoy comfortable reading spaces, study rooms, and computer labs for research.",
  },
];

export default function Home() {
  const books = getBooks();
  const students = getStudents();
  const totalBooks = books.reduce((sum, b) => sum + b.quantity, 0);
  const totalStudents = students.length;

  const stats = [
    { label: "Books Available", value: totalBooks.toLocaleString(), icon: BookOpen, gradient: "gradient-primary" },
    { label: "Active Students", value: "25", icon: Users, gradient: "gradient-accent" },
    { label: "5 Years Above", value: "Excellence", icon: Clock, gradient: "gradient-warning" },
  ];

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 gradient-page-header opacity-90" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,rgba(255,255,255,0.1),transparent_60%)]" />
        <div className="relative max-w-7xl mx-auto px-4 md:px-8 py-20 md:py-32">
          <div className="flex flex-col md:flex-row items-center gap-10">
            <div className="max-w-2xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/15 text-white/90 text-xs font-medium mb-6 backdrop-blur-sm">
                <BookOpen className="w-3.5 h-3.5" />
                Arabsa School Library
              </div>
              <h1 className="text-4xl md:text-6xl font-extrabold text-white leading-tight mb-6">
                Discover, Learn &<br />
                <span className="text-white/80">Grow With Us</span>
              </h1>
              <p className="text-lg text-white/75 mb-8 max-w-lg leading-relaxed">
                Welcome to Arabsa Pre-Primary, Primary and Middle School Library — your gateway to knowledge, research, and academic excellence.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link to="/login">
                  <Button size="lg" className="bg-white text-primary hover:bg-white/90 font-semibold">
                    Access Portal <ArrowRight className="ml-1 h-4 w-4" />
                  </Button>
                </Link>
                <Link to="/about">
                  <Button size="lg" variant="outline" className="border-white/30 text-white hover:bg-white/10">
                    Learn More
                  </Button>
                </Link>
              </div>
            </div>
            <div className="shrink-0">
              <img
                src={schoolLogo}
                alt="Arabsa Pre-Primary, Primary and Middle School Logo"
                className="w-40 h-40 md:w-56 md:h-56 rounded-full shadow-2xl border-4 border-white/20 object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="max-w-7xl mx-auto px-4 md:px-8 -mt-12 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {stats.map((stat) => (
            <Card key={stat.label} className="shadow-lg border-0">
              <CardContent className="flex items-center gap-4 p-6">
                <div className={`w-12 h-12 rounded-xl ${stat.gradient} flex items-center justify-center shrink-0`}>
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-2xl font-extrabold text-foreground">{stat.value}</p>
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="max-w-7xl mx-auto px-4 md:px-8 py-20">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-extrabold text-foreground mb-3">Why Choose Our Library?</h2>
          <p className="text-muted-foreground max-w-md mx-auto">Everything you need for academic success, all in one place.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {features.map((f) => (
            <Card key={f.title} className="group hover:shadow-lg transition-shadow border">
              <CardContent className="p-6">
                <div className="w-11 h-11 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <f.icon className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-bold text-lg text-foreground mb-2">{f.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{f.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="bg-muted">
        <div className="max-w-7xl mx-auto px-4 md:px-8 py-16 text-center">
          <h2 className="text-2xl md:text-3xl font-extrabold text-foreground mb-3">Ready to Explore?</h2>
          <p className="text-muted-foreground mb-6 max-w-md mx-auto">
            Log in to access the full library portal, manage your books, and more.
          </p>
          <Link to="/login">
            <Button size="lg" className="gradient-primary text-primary-foreground font-semibold">
              Get Started <ArrowRight className="ml-1 h-4 w-4" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
