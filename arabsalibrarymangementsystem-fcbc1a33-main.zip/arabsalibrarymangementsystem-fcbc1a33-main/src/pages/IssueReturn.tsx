import { useState } from "react";
import { ArrowLeftRight, Undo2, Search } from "lucide-react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";
import { getBooks, saveBooks, getStudents, getTransactions, saveTransactions, generateId, calculateFine, type Transaction } from "@/lib/data";

const IssueReturn = () => {
  const [books, setBooksState] = useState(getBooks);
  const [students] = useState(getStudents);
  const [transactions, setTransactions] = useState(getTransactions);
  const [search, setSearch] = useState("");
  const [issueOpen, setIssueOpen] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState("");
  const [selectedBook, setSelectedBook] = useState("");
  const [dueDate, setDueDate] = useState(() => {
    const d = new Date(); d.setDate(d.getDate() + 14);
    return d.toISOString().slice(0, 10);
  });

  const activeTransactions = transactions.filter((t) => !t.returnDate);
  const filtered = activeTransactions.filter((t) => {
    const student = students.find((s) => s.id === t.studentId);
    const book = books.find((b) => b.id === t.bookId);
    const q = search.toLowerCase();
    return !q || (student?.name.toLowerCase().includes(q) ?? false) || (book?.title.toLowerCase().includes(q) ?? false);
  });

  const handleIssue = () => {
    if (!selectedStudent || !selectedBook) { toast({ title: "Error", description: "Select student and book", variant: "destructive" }); return; }
    const book = books.find((b) => b.id === selectedBook);
    if (!book || book.available <= 0) { toast({ title: "Error", description: "Book not available", variant: "destructive" }); return; }

    const newTx: Transaction = {
      id: generateId("T", transactions), studentId: selectedStudent, bookId: selectedBook,
      issueDate: new Date().toISOString().slice(0, 10), dueDate, returnDate: null, fineAmount: 0, finePaid: false,
    };

    const updatedTx = [...transactions, newTx];
    const updatedBooks = books.map((b) => b.id === selectedBook ? { ...b, available: b.available - 1 } : b);
    setTransactions(updatedTx); setBooksState(updatedBooks);
    saveTransactions(updatedTx); saveBooks(updatedBooks);
    setIssueOpen(false); setSelectedStudent(""); setSelectedBook("");
    toast({ title: "Book issued successfully" });
  };

  const handleReturn = (tx: Transaction) => {
    const today = new Date().toISOString().slice(0, 10);
    const fine = calculateFine(tx.dueDate, today);
    const updatedTx = transactions.map((t) => t.id === tx.id ? { ...t, returnDate: today, fineAmount: fine } : t);
    const updatedBooks = books.map((b) => b.id === tx.bookId ? { ...b, available: b.available + 1 } : b);
    setTransactions(updatedTx); setBooksState(updatedBooks);
    saveTransactions(updatedTx); saveBooks(updatedBooks);
    toast({ title: fine > 0 ? `Book returned with fine: ${fine} Birr` : "Book returned successfully" });
  };

  const availableBooks = books.filter((b) => b.available > 0);

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="gradient-warning rounded-xl px-6 py-4 text-white shadow-lg flex-1">
          <h1 className="text-3xl font-extrabold text-white">🔄 Issue & Return Books</h1>
          <p className="text-white/80 text-sm font-medium mt-1">{activeTransactions.length} books currently issued</p>
        </div>
        <Button onClick={() => setIssueOpen(true)} className="gradient-warning text-white font-bold shadow-lg hover:shadow-xl transition-all hover:scale-105 border-0 h-12 px-6">
          <ArrowLeftRight className="h-4 w-4 mr-2" />Issue Book
        </Button>
      </div>

      <Card className="border-0 shadow-md">
        <CardHeader className="pb-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search by student or book..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Student</TableHead>
                <TableHead>Book</TableHead>
                <TableHead>Issue Date</TableHead>
                <TableHead>Due Date</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((t) => {
                const student = students.find((s) => s.id === t.studentId);
                const book = books.find((b) => b.id === t.bookId);
                const overdue = new Date(t.dueDate) < new Date();
                return (
                  <TableRow key={t.id} className={overdue ? "bg-destructive/5" : "hover:bg-warning/5 transition-colors"}>
                    <TableCell className="font-mono text-xs font-bold text-[hsl(var(--warning))]">{t.id}</TableCell>
                    <TableCell className="font-semibold">{student?.name}</TableCell>
                    <TableCell>{book?.title}</TableCell>
                    <TableCell>{t.issueDate}</TableCell>
                    <TableCell className="font-bold">{t.dueDate}</TableCell>
                    <TableCell>
                      {overdue ? <Badge className="gradient-destructive text-white border-0">Overdue</Badge> : <Badge className="gradient-accent text-white border-0">Active</Badge>}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="outline" size="sm" className="hover:bg-primary/10 hover:text-primary hover:border-primary" onClick={() => handleReturn(t)}>
                        <Undo2 className="h-3 w-3 mr-1" />Return
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={issueOpen} onOpenChange={setIssueOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle className="text-xl">📖 Issue a Book</DialogTitle></DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label>Student</Label>
              <Select value={selectedStudent} onValueChange={setSelectedStudent}>
                <SelectTrigger><SelectValue placeholder="Select student" /></SelectTrigger>
                <SelectContent>{students.map((s) => <SelectItem key={s.id} value={s.id}>{s.name} ({s.class})</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label>Book</Label>
              <Select value={selectedBook} onValueChange={setSelectedBook}>
                <SelectTrigger><SelectValue placeholder="Select book" /></SelectTrigger>
                <SelectContent>{availableBooks.map((b) => <SelectItem key={b.id} value={b.id}>{b.title} ({b.available} avail.)</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="grid gap-2"><Label>Due Date</Label><Input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIssueOpen(false)}>Cancel</Button>
            <Button onClick={handleIssue} className="gradient-warning text-white border-0">Issue Book</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default IssueReturn;
