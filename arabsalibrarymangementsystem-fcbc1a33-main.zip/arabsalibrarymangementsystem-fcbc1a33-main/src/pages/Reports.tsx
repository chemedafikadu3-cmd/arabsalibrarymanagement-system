import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from "@/components/ui/chart";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, PieChart, Pie, Cell, AreaChart, Area, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from "recharts";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { getBooks, getStudents, getTransactions, calculateFine } from "@/lib/data";

const Reports = () => {
  const books = getBooks();
  const students = getStudents();
  const transactions = getTransactions();

  const totalBooks = books.reduce((s, b) => s + b.quantity, 0);
  const availableBooks = books.reduce((s, b) => s + b.available, 0);
  const issuedBooks = totalBooks - availableBooks;
  const totalFinesCollected = transactions.filter((t) => t.finePaid).reduce((s, t) => s + t.fineAmount, 0);
  const pendingFines = transactions.filter((t) => !t.finePaid).reduce((s, t) => s + (t.returnDate ? t.fineAmount : calculateFine(t.dueDate)), 0);
  const returnedCount = transactions.filter((t) => t.returnDate).length;
  const activeCount = transactions.filter((t) => !t.returnDate).length;

  // Monthly issues
  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const monthlyIssues = monthNames.map((month, i) => ({
    month,
    issued: transactions.filter((t) => new Date(t.issueDate).getMonth() === i).length,
    returned: transactions.filter((t) => t.returnDate && new Date(t.returnDate).getMonth() === i).length,
  }));

  const monthlyConfig: ChartConfig = {
    issued: { label: "Issued", color: "hsl(var(--primary))" },
    returned: { label: "Returned", color: "hsl(var(--accent))" },
  };

  // Category distribution
  const catData = [
    { name: "Pre-Primary", books: books.filter((b) => b.category === "Pre-Primary").reduce((s, b) => s + b.quantity, 0), fill: "hsl(var(--primary))" },
    { name: "Primary", books: books.filter((b) => b.category === "Primary").reduce((s, b) => s + b.quantity, 0), fill: "hsl(var(--accent))" },
    { name: "Middle School", books: books.filter((b) => b.category === "Middle School").reduce((s, b) => s + b.quantity, 0), fill: "hsl(var(--warning))" },
  ];
  const catConfig: ChartConfig = {
    "Pre-Primary": { label: "Pre-Primary", color: "hsl(var(--primary))" },
    Primary: { label: "Primary", color: "hsl(var(--accent))" },
    "Middle School": { label: "Middle School", color: "hsl(var(--warning))" },
  };

  // Students by class level
  const classGroups = [
    { name: "KG", count: students.filter((s) => s.class.startsWith("KG")).length, fill: "hsl(var(--purple))" },
    { name: "Grade 1-4", count: students.filter((s) => { const g = parseInt(s.class.replace("Grade ", "")); return g >= 1 && g <= 4; }).length, fill: "hsl(var(--primary))" },
    { name: "Grade 5-8", count: students.filter((s) => { const g = parseInt(s.class.replace("Grade ", "")); return g >= 5 && g <= 8; }).length, fill: "hsl(var(--accent))" },
  ];
  const classConfig: ChartConfig = {
    KG: { label: "KG", color: "hsl(var(--purple))" },
    "Grade 1-4": { label: "Grade 1-4", color: "hsl(var(--primary))" },
    "Grade 5-8": { label: "Grade 5-8", color: "hsl(var(--accent))" },
  };

  // Top borrowed books
  const bookBorrowCount = books.map((b) => ({
    title: b.title.length > 20 ? b.title.slice(0, 20) + "…" : b.title,
    fullTitle: b.title,
    count: transactions.filter((t) => t.bookId === b.id).length,
    category: b.category,
  })).sort((a, b) => b.count - a.count).slice(0, 5);

  // Fine summary
  const finePieData = [
    { name: "Collected", value: totalFinesCollected, fill: "hsl(var(--accent))" },
    { name: "Pending", value: pendingFines, fill: "hsl(var(--destructive))" },
  ];
  const fineConfig: ChartConfig = {
    Collected: { label: "Collected", color: "hsl(var(--accent))" },
    Pending: { label: "Pending", color: "hsl(var(--destructive))" },
  };

  // Radar chart data - library health
  const radarData = [
    { metric: "Books", value: Math.min(totalBooks / 5, 100) },
    { metric: "Students", value: Math.min(students.length * 10, 100) },
    { metric: "Activity", value: Math.min(transactions.length * 15, 100) },
    { metric: "Returns", value: returnedCount > 0 ? Math.min((returnedCount / transactions.length) * 100, 100) : 0 },
    { metric: "Availability", value: totalBooks > 0 ? (availableBooks / totalBooks) * 100 : 0 },
  ];
  const radarConfig: ChartConfig = { value: { label: "Score", color: "hsl(var(--primary))" } };

  const catBadgeColor: Record<string, string> = {
    "Pre-Primary": "gradient-primary text-white border-0",
    "Primary": "gradient-accent text-white border-0",
    "Middle School": "gradient-warning text-white border-0",
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="gradient-purple rounded-xl px-6 py-4 text-white shadow-lg">
        <h1 className="text-3xl font-extrabold text-white">📊 Reports & Analytics</h1>
        <p className="text-white/80 text-sm font-medium mt-1">Library performance overview</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Total Transactions", value: transactions.length, gradient: "gradient-primary" },
          { label: "Active Issues", value: activeCount, gradient: "gradient-warning" },
          { label: "Fines Collected", value: `${totalFinesCollected} Birr`, gradient: "gradient-accent" },
          { label: "Fines Pending", value: `${pendingFines} Birr`, gradient: "gradient-destructive" },
        ].map((s, i) => (
          <Card key={s.label} className="border-0 shadow-md overflow-hidden animate-scale-in" style={{ animationDelay: `${i * 80}ms`, animationFillMode: "backwards" }}>
            <div className={`${s.gradient} h-1.5`} />
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-extrabold">{s.value}</p>
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mt-1">{s.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="border-0 shadow-md animate-fade-in" style={{ animationDelay: "200ms", animationFillMode: "backwards" }}>
          <CardHeader>
            <CardTitle className="text-lg font-extrabold flex items-center gap-2">
              <span className="w-3 h-3 rounded-full gradient-primary inline-block" />
              Monthly Issue & Return Trends
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer config={monthlyConfig} className="h-[280px] w-full">
              <AreaChart data={monthlyIssues} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="rptGradIssue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.35} />
                    <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="rptGradReturn" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--accent))" stopOpacity={0.35} />
                    <stop offset="95%" stopColor="hsl(var(--accent))" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Area type="monotone" dataKey="issued" stroke="hsl(var(--primary))" strokeWidth={2.5} fill="url(#rptGradIssue)" animationDuration={1200} />
                <Area type="monotone" dataKey="returned" stroke="hsl(var(--accent))" strokeWidth={2.5} fill="url(#rptGradReturn)" animationDuration={1200} />
              </AreaChart>
            </ChartContainer>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-md animate-fade-in" style={{ animationDelay: "300ms", animationFillMode: "backwards" }}>
          <CardHeader>
            <CardTitle className="text-lg font-extrabold flex items-center gap-2">
              <span className="w-3 h-3 rounded-full gradient-accent inline-block" />
              Students by Level
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer config={classConfig} className="h-[240px] w-full">
              <BarChart data={classGroups} margin={{ top: 5, right: 20, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="name" tick={{ fontSize: 12, fontWeight: 700 }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Bar dataKey="count" radius={[8, 8, 0, 0]} animationDuration={1000}>
                  {classGroups.map((entry, index) => (
                    <Cell key={`cls-${index}`} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ChartContainer>
            <div className="flex justify-center gap-4 mt-2">
              {classGroups.map((c) => (
                <div key={c.name} className="flex items-center gap-1.5 text-xs font-bold">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: c.fill }} />
                  {c.name}: {c.count}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="border-0 shadow-md animate-fade-in" style={{ animationDelay: "400ms", animationFillMode: "backwards" }}>
          <CardHeader>
            <CardTitle className="text-lg font-extrabold flex items-center gap-2">
              <span className="w-3 h-3 rounded-full gradient-warning inline-block" />
              Category Breakdown
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer config={catConfig} className="h-[220px] w-full">
              <PieChart>
                <ChartTooltip content={<ChartTooltipContent />} />
                <Pie data={catData} cx="50%" cy="50%" innerRadius={45} outerRadius={80} paddingAngle={5} dataKey="books" nameKey="name" animationDuration={1000} strokeWidth={2} stroke="hsl(var(--card))">
                  {catData.map((entry, index) => (
                    <Cell key={`cat-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
              </PieChart>
            </ChartContainer>
            <div className="flex justify-center gap-3 mt-2">
              {catData.map((c) => (
                <div key={c.name} className="flex items-center gap-1.5 text-xs font-bold">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: c.fill }} />
                  {c.name}: {c.books}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-md animate-fade-in" style={{ animationDelay: "500ms", animationFillMode: "backwards" }}>
          <CardHeader>
            <CardTitle className="text-lg font-extrabold flex items-center gap-2">
              <span className="w-3 h-3 rounded-full gradient-destructive inline-block" />
              Fine Summary
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer config={fineConfig} className="h-[220px] w-full">
              <PieChart>
                <ChartTooltip content={<ChartTooltipContent />} />
                <Pie data={finePieData} cx="50%" cy="50%" innerRadius={45} outerRadius={80} paddingAngle={5} dataKey="value" nameKey="name" animationDuration={1000} strokeWidth={2} stroke="hsl(var(--card))">
                  {finePieData.map((entry, index) => (
                    <Cell key={`fine-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
              </PieChart>
            </ChartContainer>
            <div className="flex justify-center gap-4 mt-2">
              {finePieData.map((f) => (
                <div key={f.name} className="flex items-center gap-1.5 text-xs font-bold">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: f.fill }} />
                  {f.name}: {f.value} Birr
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-md animate-fade-in" style={{ animationDelay: "600ms", animationFillMode: "backwards" }}>
          <CardHeader>
            <CardTitle className="text-lg font-extrabold flex items-center gap-2">
              <span className="w-3 h-3 rounded-full gradient-purple inline-block" />
              Library Health
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer config={radarConfig} className="h-[250px] w-full">
              <RadarChart cx="50%" cy="50%" outerRadius="70%" data={radarData}>
                <PolarGrid className="stroke-muted" />
                <PolarAngleAxis dataKey="metric" tick={{ fontSize: 11, fontWeight: 600 }} />
                <PolarRadiusAxis tick={{ fontSize: 10 }} domain={[0, 100]} />
                <Radar dataKey="value" stroke="hsl(var(--primary))" fill="hsl(var(--primary))" fillOpacity={0.25} strokeWidth={2} animationDuration={1200} />
              </RadarChart>
            </ChartContainer>
          </CardContent>
        </Card>
      </div>

      {/* Top Borrowed Books */}
      <Card className="border-0 shadow-md animate-fade-in" style={{ animationDelay: "700ms", animationFillMode: "backwards" }}>
        <CardHeader>
          <CardTitle className="text-lg font-extrabold flex items-center gap-2">
            <span className="w-3 h-3 rounded-full gradient-primary inline-block" />
            🏆 Most Borrowed Books
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Rank</TableHead>
                <TableHead>Title</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Times Borrowed</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {bookBorrowCount.map((b, i) => (
                <TableRow key={b.fullTitle} className="hover:bg-primary/5 transition-colors">
                  <TableCell>
                    <span className={`inline-flex items-center justify-center w-7 h-7 rounded-full font-extrabold text-sm text-white ${i === 0 ? "gradient-warning" : i === 1 ? "gradient-primary" : i === 2 ? "gradient-accent" : "bg-muted text-muted-foreground"}`}>
                      {i + 1}
                    </span>
                  </TableCell>
                  <TableCell className="font-semibold">{b.fullTitle}</TableCell>
                  <TableCell><Badge className={catBadgeColor[b.category]}>{b.category}</Badge></TableCell>
                  <TableCell className="font-extrabold text-lg text-primary">{b.count}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default Reports;
