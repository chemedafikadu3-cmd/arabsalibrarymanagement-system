import { useState } from "react";
import { Plus, Pencil, Trash2, Search } from "lucide-react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";
import { getStudents, saveStudents, generateId, type Student } from "@/lib/data";

const classes = ["KG-1", "KG-2", "Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5", "Grade 6", "Grade 7", "Grade 8"];
const emptyStudent: Omit<Student, "id"> = { name: "", class: "KG-1", section: "A", phone: "", admissionDate: new Date().toISOString().slice(0, 10) };

const classColorMap = (cls: string) => {
  if (cls.startsWith("KG")) return "gradient-purple text-white border-0";
  const grade = parseInt(cls.replace("Grade ", ""));
  if (grade <= 4) return "gradient-primary text-white border-0";
  return "gradient-accent text-white border-0";
};

const Students = () => {
  const [students, setStudents] = useState(getStudents);
  const [search, setSearch] = useState("");
  const [classFilter, setClassFilter] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Student | null>(null);
  const [form, setForm] = useState<Omit<Student, "id">>(emptyStudent);

  const filtered = students.filter((s) => {
    const matchSearch = s.name.toLowerCase().includes(search.toLowerCase());
    const matchClass = classFilter === "all" || s.class === classFilter;
    return matchSearch && matchClass;
  });

  const openAdd = () => { setEditing(null); setForm(emptyStudent); setDialogOpen(true); };
  const openEdit = (s: Student) => { setEditing(s); setForm({ name: s.name, class: s.class, section: s.section, phone: s.phone, admissionDate: s.admissionDate }); setDialogOpen(true); };

  const handleSave = () => {
    if (!form.name) { toast({ title: "Error", description: "Name is required", variant: "destructive" }); return; }
    let updated: Student[];
    if (editing) {
      updated = students.map((s) => s.id === editing.id ? { ...s, ...form } : s);
      toast({ title: "Student updated" });
    } else {
      updated = [...students, { id: generateId("S", students), ...form }];
      toast({ title: "Student added" });
    }
    setStudents(updated);
    saveStudents(updated);
    setDialogOpen(false);
  };

  const handleDelete = (id: string) => {
    const updated = students.filter((s) => s.id !== id);
    setStudents(updated);
    saveStudents(updated);
    toast({ title: "Student deleted" });
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="gradient-accent rounded-xl px-6 py-4 text-white shadow-lg flex-1">
          <h1 className="text-3xl font-extrabold text-white">👨‍🎓 Student Management</h1>
          <p className="text-white/80 text-sm font-medium mt-1">{students.length} students enrolled</p>
        </div>
        <Button onClick={openAdd} className="gradient-accent text-white font-bold shadow-lg hover:shadow-xl transition-all hover:scale-105 border-0 h-12 px-6">
          <Plus className="h-4 w-4 mr-2" />Add Student
        </Button>
      </div>

      <Card className="border-0 shadow-md">
        <CardHeader className="pb-3">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search by name..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
            </div>
            <Select value={classFilter} onValueChange={setClassFilter}>
              <SelectTrigger className="w-[180px]"><SelectValue placeholder="Class" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Classes</SelectItem>
                {classes.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Class</TableHead>
                <TableHead>Section</TableHead>
                <TableHead className="hidden md:table-cell">Phone</TableHead>
                <TableHead className="hidden lg:table-cell">Admission</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((s) => (
                <TableRow key={s.id} className="hover:bg-accent/5 transition-colors">
                  <TableCell className="font-mono text-xs font-bold text-accent">{s.id}</TableCell>
                  <TableCell className="font-semibold">{s.name}</TableCell>
                  <TableCell><Badge className={classColorMap(s.class)}>{s.class}</Badge></TableCell>
                  <TableCell><Badge variant="outline" className="font-bold">{s.section}</Badge></TableCell>
                  <TableCell className="hidden md:table-cell">{s.phone}</TableCell>
                  <TableCell className="hidden lg:table-cell">{s.admissionDate}</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" className="hover:bg-primary/10 hover:text-primary" onClick={() => openEdit(s)}><Pencil className="h-4 w-4" /></Button>
                    <Button variant="ghost" size="icon" className="hover:bg-destructive/10" onClick={() => handleDelete(s.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle className="text-xl">{editing ? "✏️ Edit Student" : "🎓 Add New Student"}</DialogTitle></DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2"><Label>Full Name</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label>Class</Label>
                <Select value={form.class} onValueChange={(v) => setForm({ ...form, class: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{classes.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="grid gap-2"><Label>Section</Label><Input value={form.section} onChange={(e) => setForm({ ...form, section: e.target.value })} /></div>
            </div>
            <div className="grid gap-2"><Label>Phone</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
            <div className="grid gap-2"><Label>Admission Date</Label><Input type="date" value={form.admissionDate} onChange={(e) => setForm({ ...form, admissionDate: e.target.value })} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} className="gradient-accent text-white border-0">{editing ? "Update" : "Add Student"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Students;
