import { useState } from "react";
import { useAuth, UserRole, AppUser } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { UserPlus, Pencil, Trash2, Shield, ShieldCheck, BookOpen, Key, Search, Users } from "lucide-react";

const roleBadge: Record<UserRole, { label: string; className: string; icon: React.ReactNode }> = {
  admin: { label: "Admin", className: "bg-primary/15 text-primary border-primary/30", icon: <Shield className="h-3 w-3" /> },
  "sub-admin": { label: "Sub-Admin", className: "bg-accent/15 text-accent border-accent/30", icon: <ShieldCheck className="h-3 w-3" /> },
  librarian: { label: "Librarian", className: "bg-amber-500/15 text-amber-700 border-amber-500/30", icon: <BookOpen className="h-3 w-3" /> },
};

export default function UserManagement() {
  const { currentUser, getUsers, addUser, updateUser, deleteUser, changePassword, hasPermission } = useAuth();
  const { toast } = useToast();
  const users = getUsers();

  const [search, setSearch] = useState("");
  const [showAdd, setShowAdd] = useState(false);
  const [showEdit, setShowEdit] = useState<AppUser | null>(null);
  const [showChangePassword, setShowChangePassword] = useState(false);
  const [showResetPassword, setShowResetPassword] = useState<AppUser | null>(null);

  // Add user form
  const [newUsername, setNewUsername] = useState("");
  const [newFullName, setNewFullName] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [newRole, setNewRole] = useState<UserRole>("librarian");

  // Edit user form
  const [editUsername, setEditUsername] = useState("");
  const [editFullName, setEditFullName] = useState("");
  const [editRole, setEditRole] = useState<UserRole>("librarian");
  const [editActive, setEditActive] = useState(true);

  // Change password form
  const [oldPw, setOldPw] = useState("");
  const [newPw, setNewPw] = useState("");
  const [confirmPw, setConfirmPw] = useState("");

  // Reset password form
  const [resetPw, setResetPw] = useState("");

  const filtered = users.filter(
    (u) =>
      u.fullName.toLowerCase().includes(search.toLowerCase()) ||
      u.username.toLowerCase().includes(search.toLowerCase()) ||
      u.role.toLowerCase().includes(search.toLowerCase())
  );

  const handleAdd = () => {
    if (!newUsername.trim() || !newFullName.trim() || !newPassword.trim()) {
      toast({ title: "Error", description: "All fields are required.", variant: "destructive" });
      return;
    }
    if (newPassword.length < 6) {
      toast({ title: "Error", description: "Password must be at least 6 characters.", variant: "destructive" });
      return;
    }
    const success = addUser({ username: newUsername.trim(), fullName: newFullName.trim(), password: newPassword, role: newRole, active: true });
    if (success) {
      toast({ title: "User Created", description: `${newFullName} has been added as ${newRole}.` });
      setShowAdd(false);
      setNewUsername(""); setNewFullName(""); setNewPassword(""); setNewRole("librarian");
    } else {
      toast({ title: "Error", description: "Username already exists.", variant: "destructive" });
    }
  };

  const openEdit = (user: AppUser) => {
    setShowEdit(user);
    setEditUsername(user.username);
    setEditFullName(user.fullName);
    setEditRole(user.role);
    setEditActive(user.active);
  };

  const handleEdit = () => {
    if (!showEdit) return;
    const success = updateUser(showEdit.id, { username: editUsername.trim(), fullName: editFullName.trim(), role: editRole, active: editActive });
    if (success) {
      toast({ title: "User Updated", description: `${editFullName} has been updated.` });
      setShowEdit(null);
    } else {
      toast({ title: "Error", description: "Username already exists.", variant: "destructive" });
    }
  };

  const handleDelete = (user: AppUser) => {
    if (user.id === currentUser?.id) {
      toast({ title: "Error", description: "You cannot delete your own account.", variant: "destructive" });
      return;
    }
    const success = deleteUser(user.id);
    if (success) {
      toast({ title: "User Deleted", description: `${user.fullName} has been removed.` });
    }
  };

  const handleChangePassword = () => {
    if (newPw.length < 6) {
      toast({ title: "Error", description: "New password must be at least 6 characters.", variant: "destructive" });
      return;
    }
    if (newPw !== confirmPw) {
      toast({ title: "Error", description: "Passwords do not match.", variant: "destructive" });
      return;
    }
    const success = changePassword(oldPw, newPw);
    if (success) {
      toast({ title: "Password Changed", description: "Your password has been updated successfully." });
      setShowChangePassword(false);
      setOldPw(""); setNewPw(""); setConfirmPw("");
    } else {
      toast({ title: "Error", description: "Current password is incorrect.", variant: "destructive" });
    }
  };

  const handleResetPassword = () => {
    if (!showResetPassword) return;
    if (resetPw.length < 6) {
      toast({ title: "Error", description: "Password must be at least 6 characters.", variant: "destructive" });
      return;
    }
    updateUser(showResetPassword.id, { password: resetPw });
    toast({ title: "Password Reset", description: `Password for ${showResetPassword.fullName} has been reset.` });
    setShowResetPassword(null);
    setResetPw("");
  };

  const isAdmin = currentUser?.role === "admin";

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold text-foreground flex items-center gap-2" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
            <Users className="h-8 w-8 text-primary" />
            User Management
          </h1>
          <p className="text-muted-foreground font-medium mt-1">Manage admin, sub-admin, and librarian accounts</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => setShowChangePassword(true)} variant="outline" className="font-semibold">
            <Key className="h-4 w-4 mr-2" /> Change My Password
          </Button>
          {isAdmin && (
            <Button onClick={() => setShowAdd(true)} className="font-bold bg-gradient-to-r from-primary to-accent text-primary-foreground shadow-lg">
              <UserPlus className="h-4 w-4 mr-2" /> Add User
            </Button>
          )}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {(["admin", "sub-admin", "librarian"] as UserRole[]).map((role) => {
          const count = users.filter((u) => u.role === role).length;
          const info = roleBadge[role];
          return (
            <Card key={role} className="animate-scale-in hover:shadow-lg transition-shadow">
              <CardContent className="p-5 flex items-center gap-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${info.className}`}>
                  {info.icon}
                </div>
                <div>
                  <p className="text-2xl font-extrabold text-foreground">{count}</p>
                  <p className="text-sm text-muted-foreground font-medium">{info.label}s</p>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Search users..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-10" />
      </div>

      {/* Users Table */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Full Name</TableHead>
                <TableHead>Username</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Created</TableHead>
                {isAdmin && <TableHead className="text-right">Actions</TableHead>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((user) => {
                const info = roleBadge[user.role];
                return (
                  <TableRow key={user.id}>
                    <TableCell className="font-semibold">{user.fullName}</TableCell>
                    <TableCell className="text-muted-foreground">{user.username}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className={`gap-1 ${info.className}`}>
                        {info.icon} {info.label}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant={user.active ? "default" : "secondary"} className={user.active ? "bg-accent/15 text-accent border-accent/30" : ""}>
                        {user.active ? "Active" : "Inactive"}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm">{user.createdAt}</TableCell>
                    {isAdmin && (
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1">
                          <Button size="icon" variant="ghost" onClick={() => openEdit(user)} title="Edit">
                            <Pencil className="h-4 w-4 text-primary" />
                          </Button>
                          <Button size="icon" variant="ghost" onClick={() => { setShowResetPassword(user); setResetPw(""); }} title="Reset Password">
                            <Key className="h-4 w-4 text-amber-600" />
                          </Button>
                          {user.id !== currentUser?.id && (
                            <Button size="icon" variant="ghost" onClick={() => handleDelete(user)} title="Delete">
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    )}
                  </TableRow>
                );
              })}
              {filtered.length === 0 && (
                <TableRow>
                  <TableCell colSpan={6} className="text-center text-muted-foreground py-8">No users found.</TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Add User Dialog */}
      <Dialog open={showAdd} onOpenChange={setShowAdd}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="font-extrabold text-xl">Create New User</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-semibold">Full Name</label>
              <Input value={newFullName} onChange={(e) => setNewFullName(e.target.value)} placeholder="e.g. Abebe Kebede" />
            </div>
            <div>
              <label className="text-sm font-semibold">Username</label>
              <Input value={newUsername} onChange={(e) => setNewUsername(e.target.value)} placeholder="e.g. abebe" />
            </div>
            <div>
              <label className="text-sm font-semibold">Password</label>
              <Input type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} placeholder="Min 6 characters" />
            </div>
            <div>
              <label className="text-sm font-semibold">Role</label>
              <Select value={newRole} onValueChange={(v) => setNewRole(v as UserRole)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">Admin</SelectItem>
                  <SelectItem value="sub-admin">Sub-Admin</SelectItem>
                  <SelectItem value="librarian">Librarian</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAdd(false)}>Cancel</Button>
            <Button onClick={handleAdd} className="font-bold bg-gradient-to-r from-primary to-accent text-primary-foreground">Create User</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit User Dialog */}
      <Dialog open={!!showEdit} onOpenChange={() => setShowEdit(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="font-extrabold text-xl">Edit User</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-semibold">Full Name</label>
              <Input value={editFullName} onChange={(e) => setEditFullName(e.target.value)} />
            </div>
            <div>
              <label className="text-sm font-semibold">Username</label>
              <Input value={editUsername} onChange={(e) => setEditUsername(e.target.value)} />
            </div>
            <div>
              <label className="text-sm font-semibold">Role</label>
              <Select value={editRole} onValueChange={(v) => setEditRole(v as UserRole)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">Admin</SelectItem>
                  <SelectItem value="sub-admin">Sub-Admin</SelectItem>
                  <SelectItem value="librarian">Librarian</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2">
              <input type="checkbox" id="editActive" checked={editActive} onChange={(e) => setEditActive(e.target.checked)} className="rounded border-input" />
              <label htmlFor="editActive" className="text-sm font-semibold">Active</label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEdit(null)}>Cancel</Button>
            <Button onClick={handleEdit} className="font-bold">Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Change My Password Dialog */}
      <Dialog open={showChangePassword} onOpenChange={setShowChangePassword}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="font-extrabold text-xl">Change Password</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-semibold">Current Password</label>
              <Input type="password" value={oldPw} onChange={(e) => setOldPw(e.target.value)} />
            </div>
            <div>
              <label className="text-sm font-semibold">New Password</label>
              <Input type="password" value={newPw} onChange={(e) => setNewPw(e.target.value)} placeholder="Min 6 characters" />
            </div>
            <div>
              <label className="text-sm font-semibold">Confirm New Password</label>
              <Input type="password" value={confirmPw} onChange={(e) => setConfirmPw(e.target.value)} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowChangePassword(false)}>Cancel</Button>
            <Button onClick={handleChangePassword} className="font-bold">Update Password</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reset Password Dialog */}
      <Dialog open={!!showResetPassword} onOpenChange={() => setShowResetPassword(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="font-extrabold text-xl">Reset Password for {showResetPassword?.fullName}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-semibold">New Password</label>
              <Input type="password" value={resetPw} onChange={(e) => setResetPw(e.target.value)} placeholder="Min 6 characters" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowResetPassword(null)}>Cancel</Button>
            <Button onClick={handleResetPassword} className="font-bold bg-gradient-to-r from-primary to-accent text-primary-foreground">Reset Password</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
